package com.livescore.livescoreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiveScoreAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiveScoreAppApplication.class, args);
	}

}
