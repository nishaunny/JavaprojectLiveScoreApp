package com.stackroute.demo.exception;

public class LeagueAlreadyExistsException extends Exception {

	public LeagueAlreadyExistsException(String message) {
		super(message);
	}
}
