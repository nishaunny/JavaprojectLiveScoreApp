export class League {
    leagueName!: string;
    userName!: string;
    // country!: string;
    points!: number;
    teamName!: string;
    rank!:number;
    year!:string;
    category!:string;
}
