import { League } from './league';

describe('League', () => {
  it('should create an instance', () => {
    expect(new League()).toBeTruthy();
  });
});
