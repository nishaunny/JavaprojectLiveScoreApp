export class Favourites {
    // favouriteId!:number;
    teamName!:string;
    userName!:string;
}
