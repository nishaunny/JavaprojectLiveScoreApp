import { Favourites } from './favourites';

describe('Favourites', () => {
  it('should create an instance', () => {
    expect(new Favourites()).toBeTruthy();
  });
});
